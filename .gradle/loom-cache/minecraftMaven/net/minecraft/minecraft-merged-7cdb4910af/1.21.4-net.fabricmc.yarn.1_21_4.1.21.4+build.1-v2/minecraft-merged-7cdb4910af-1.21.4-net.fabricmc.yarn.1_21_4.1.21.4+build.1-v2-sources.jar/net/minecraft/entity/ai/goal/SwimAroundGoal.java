package net.minecraft.entity.ai.goal;

import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

public class SwimAroundGoal extends WanderAroundGoal {
	public SwimAroundGoal(PathAwareEntity pathAwareEntity, double d, int i) {
		super(pathAwareEntity, d, i);
	}

	@Nullable
	@Override
	protected Vec3d getWanderTarget() {
		return TargetUtil.find(this.mob, 10, 7);
	}
}
